abstract class AppConstants{
  static String userId = '';
}