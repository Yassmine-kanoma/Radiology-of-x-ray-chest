class DoctorModel{
 final String name,address,location;

  DoctorModel({required this.name, required this.address, required this.location});
}